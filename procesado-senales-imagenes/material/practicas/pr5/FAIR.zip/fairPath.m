function value=fairPath; value='D:\compartido\cplatero\docencia\PSI\pr�cticas\pr5\FAIR';
