function varargout = ejemploGUI(varargin)
% EJEMPLOGUI M-file for ejemploGUI.fig
%      EJEMPLOGUI, by itself, creates a new EJEMPLOGUI or raises the existing
%      singleton*.
%
%      H = EJEMPLOGUI returns the handle to a new EJEMPLOGUI or the handle to
%      the existing singleton*.
%
%      EJEMPLOGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in EJEMPLOGUI.M with the given input arguments.
%
%      EJEMPLOGUI('Property','Value',...) creates a new EJEMPLOGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ejemploGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ejemploGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ejemploGUI

% Last Modified by GUIDE v2.5 09-Feb-2011 11:27:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ejemploGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @ejemploGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ejemploGUI is made visible.
function ejemploGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ejemploGUI (see VARARGIN)

% Choose default command line output for ejemploGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ejemploGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ejemploGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
data = guihandles(gcbf);
imgEnt = imread('cameraman.tif');
axes(handles.axes1);
imshow(imgEnt);

set(data.edit1,'Enable','on');
set(data.edit1,'String',num2str(graythresh(imgEnt)*255));
set(data.edit1,'Enable','inactive');

axes(handles.axes3);
imshow(im2bw(imgEnt));


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


