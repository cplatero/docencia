function varargout = pr4MIP_VA_GUI(varargin)
% PR4MIP_VA_GUI M-file for pr4MIP_VA_GUI.fig
%      PR4MIP_VA_GUI, by itself, creates a new PR4MIP_VA_GUI or raises the existing
%      singleton*.
%
%      H = PR4MIP_VA_GUI returns the handle to a new PR4MIP_VA_GUI or the handle to
%      the existing singleton*.
%
%      PR4MIP_VA_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PR4MIP_VA_GUI.M with the given input arguments.
%
%      PR4MIP_VA_GUI('Property','Value',...) creates a new PR4MIP_VA_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pr4MIP_VA_GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pr4MIP_VA_GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pr4MIP_VA_GUI

% Last Modified by GUIDE v2.5 24-Feb-2011 11:06:37

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pr4MIP_VA_GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @pr4MIP_VA_GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before pr4MIP_VA_GUI is made visible.
function pr4MIP_VA_GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pr4MIP_VA_GUI (see VARARGIN)

% Choose default command line output for pr4MIP_VA_GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes pr4MIP_VA_GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = pr4MIP_VA_GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
data = guihandles(gcbf);
directorio = uigetdir(pwd,'Directorio de im�genes');

if(directorio==0)
    return;
end
set(data.edit1,'Enable','on');
set(data.edit1,'String',directorio);
set(data.edit1,'Enable','off');


%Leer la estructura del directorio
strDir = dir ( directorio );

%N�mero de ficheros y directorios en ese path
numObjs = size(strDir,1);

k=1;
global listaImagenes;
listaImagenes=[];
for i=1:numObjs
    if (~strDir(i).isdir)
        TamStr=size(strDir(i).name,2);
        TipoFich = [strDir(i).name(1,TamStr-3:TamStr)];
        if ( strcmp(TipoFich,'.jpg') ||strcmp(TipoFich,'.JPG') ||...
             strcmp(TipoFich,'.bmp') ||strcmp(TipoFich,'.BMP') ||...
             strcmp(TipoFich,'.tif') ||strcmp(TipoFich,'.TIF') )
            listaImagenes{k} = strcat(directorio,'\\',strDir(i).name);
            k = k +1;
        end
    end
end
numFotos = numel(listaImagenes);
set(data.edit2,'Enable','on');
set(data.edit2,'String',int2str(numFotos));
set(data.edit2,'Enable','off');
global indiceFoto;
if(numFotos>0)
    indiceFoto=1;
    set(data.pushbutton1,'Enable','off');
    set(data.pushbutton2,'Enable','on');
end
    
    
    



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global listaImagenes;
global indiceFoto;
data = guihandles(gcbf);
numFotos = numel(listaImagenes);
j=1;
if(indiceFoto <= numFotos)
    axes(handles.axes1);
    imshow(imread(listaImagenes{j}));
    set(data.edit2,'Enable','on');
    set(data.edit2,'String',int2str(numFotos-indiceFoto));
    set(data.edit2,'Enable','off');
    indiceFoto = indiceFoto + 1;
else
    indiceFoto = 0;
    set(data.pushbutton1,'Enable','on');
    set(data.pushbutton2,'Enable','off');   
end

