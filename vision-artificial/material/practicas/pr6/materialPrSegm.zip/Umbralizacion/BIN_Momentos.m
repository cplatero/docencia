function Umbral = BIN_Momentos(histograma,area)

	m1=0; m2=0; m3=0;
    
    i=1;
	while(i<=255)
        m1=m1+(i*histograma(i));
		m2=m2+(i*i*histograma(i));
		m3=m3+(i*i*i*histograma(i));
        i= i+1;
    end
	
	m1=m1/area; m2=m2/area; m3=m3/area;

	c0=((m1*m3) - (m2*m2))/(m2 - (m1*m1));
	c1=((m1*m2) - m3)/(m2 - (m1*m1));

	z=0.5*(sqrt((c1*c1)-(4*c0)) - c1);

	p0=(z - m1)/sqrt((c1*c1)-(4*c0));

	pt=0;
    i=1;
	while(i<257)
        pt= pt+(histograma(i)/area);
        if(pt>=p0)
            break;
        end
        i=i+1;
    end
    

    Umbral = i-1;
    
