function Umbral=BIN_SigmaTres(histograma,Area)
% unsigned char BIN_SigmaTres(unsigned long *histograma,unsigned long area);

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 21/05/03
%
%
i=1;
media=0;
varianza=0;
while(i<=256)
    media=media+(histograma(i)*i);
    
    i=i+1;
end
media=media/Area;
i=1;
while(i<=256)
    varianza=varianza+(histograma(i)*(i-media)*(i-media));
    i=i+1;
end
varianza=varianza/Area;
desvtip=sqrt(varianza);
Umbral=media-(3*desvtip)-1;
if(Umbral<0)
    Umbral=0;
end
if(Umbral>256)
    Umbral=255;
end

    
    
    