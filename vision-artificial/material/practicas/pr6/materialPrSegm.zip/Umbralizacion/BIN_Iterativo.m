function Umbral = BIN_Iterativo(histograma)

i=1;	
while(histograma(i) ==0)
    i=i+1;
end
j=256;
while(histograma(j)==0)
    j = j-1;
end

tant=(j+i)/2;
mt0=0;
mt1=0;
i=1;
while(i<257)
    mt0=mt0+histograma(i);
    mt1=mt1+(i*histograma(i));
    i = i+1;
end
tsig=0;
iteraciones=0;
while(tant~=tsig)
	if(iteraciones~=0)
        tant=tsig;
    end
    m0=0;
    m1=0;
    i=1;
    while(i<tant)
        m0=m0+histograma(i);
        m1=m1+(i*histograma(i));
        i= i+1;
    end
    tsig= uint8(m1/(m0*2.0)+(mt1-m1)/...
			 ((mt0-m0)*2.0));
    iteraciones=iteraciones+1;
end

Umbral = uint8(double(tsig)-1);
