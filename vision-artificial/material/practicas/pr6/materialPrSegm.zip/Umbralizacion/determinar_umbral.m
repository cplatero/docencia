function determinar_umbral( NomFichImg )
%Objetivos
%	Determinar el mejor umbral para separar un objeto del fondo
%
%
%Autor: Carlos Platero ELAI-UPM
%Rev 0.0.0
%09/05/02

%Leer la imagen del nucleo de la cometa
ImgEnt = imread ( NomFichImg );

%Histograma
Hist = imhist(ImgEnt(:,:,1));

UmbralBIN(1) = BIN_Otsu(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 1
UmbralBIN(2) = BIN_VarianzaContinua(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 2
UmbralBIN(3) = BIN_Iterativo(Hist); %Algoritmo 3
UmbralBIN(4) = BIN_Concavidad(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 4
UmbralBIN(5) = BIN_ConcavModificada(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 5
UmbralBIN(6) = BIN_ErrorMinimo(Hist); %Algoritmo 6
UmbralBIN(7) = BIN_Momentos(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 7
UmbralBIN(8) = BIN_EntropiaPun1(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 8
UmbralBIN(9) = BIN_EntropiaPun2(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 9
UmbralBIN(10)= BIN_EntropiaKSW(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 10
UmbralBIN(11)= BIN_EntropiaJB(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 11
UmbralBIN(12)= BIN_SigmaTres(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 12
UmbralBIN(13)= BIN_Bimodal(Hist); %Algoritmo 13
UmbralBIN(14)= BIN_Monomodal(Hist,size(ImgEnt,1)*size(ImgEnt,2)); %Algoritmo 14


for i=1:numel(UmbralBIN)
    imshow([ImgEnt,uint8((ImgEnt>UmbralBIN(i)).*255)]);
    title(sprintf('Umbral %d con nivel %d',i,UmbralBIN(i)));
    pause;
end







   
   



