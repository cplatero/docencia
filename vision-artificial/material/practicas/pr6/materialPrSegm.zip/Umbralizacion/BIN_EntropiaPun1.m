function Umbral=BIN_EntropiaPun1(histograma,Area)
% unsigned char BIN_EntropiaPun1(unsigned long *histograma,unsigned long area);

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 20/05/03
%
%
HT=0;
i=1;
while(i<=256)
    prob(i)=histograma(i)/Area;
    if(prob(i)>0)
        HT= HT - (prob(i)*log(prob(i)));
    end
    i=i+1;
end
maximo=1;
while(maximo<=256)
    f(maximo)=0;
    maximo=maximo+1;
end
maximo=1;

t=1;
while(t<=256)
    maxprob1=0;
    h=0;
    sumprob=0;
    i=1;
    while(i<=t)
        sumprob=sumprob+prob(i);
        if(prob(i)>0)
            h=h-(prob(i)*log(prob(i)));
        end
        if(prob(i)>maxprob1)
            maxprob1=prob(i);
        end
        i=i+1;
    end
    maxprob2=0;
    i=t+1;
    while(i<=256)
        if(prob(i)>maxprob2)
            maxprob2=prob(i);
        end
        if((sumprob>0) & ((1-sumprob)>0) & (maxprob2 ~=0) & (HT ~=0) & (maxprob1 >0))
            f(t)=(h*log(sumprob))/(HT*log(maxprob1))+ ((1-(h/HT))*(log(1-sumprob)/log(maxprob2)));
        else if (sumprob ==0)
                f(t)=h/HT;
            else if (sumprob==1)
                    f(t)=1-(h/HT);
                end
            end
        end
        if (f(t)>f(maximo))
            maximo=t;
        end
        i=i+1;
    end
    t=t+1;
end
Umbral=maximo-1;

            
                    