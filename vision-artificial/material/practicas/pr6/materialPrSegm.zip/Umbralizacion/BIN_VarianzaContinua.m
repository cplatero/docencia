function Umbral=BIN_VarianzaContinua(histograma,Area)
%unsigned char BIN_VarianzaContinua(unsigned long *histograma,unsigned long area)

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 16/05/03
%
%

   
 minimo=1;
 while(minimo<=256)
    varinter(minimo)=0;
    minimo=minimo+1;
 end
 minimo=1;
 i=1;
 while (histograma(i) == 0)
 i = i+1;
 end
    
    m0total=1;
    m1total=0;
 
   minimo=i;

t=1;
while(t<=256)
    m1total=m1total+ ((t*histograma(t))/Area);
    t=t+1;
end
t=1;
while(t<=256)
    m1=0;
    m0=0;
    i=1;
    while(i<=t)
        
      m1=m1+(histograma(i)*i)/Area;
      m0=m0+((histograma(i)/Area));
      i=i+1;
    end
    n1=m1total-m1;
    n0=m0total-m0;
    if (n0 & m0)
        varinter(t)=abs(2*t-(m1/m0)-(n1/n0));
    else
        varinter(t)=-1;
    end
    t=t+1;
end


t=1;
while(t<=256)
    if ((varinter(t) < varinter(minimo) ) & (varinter(t) > 0))
        minimo = t;
    end
    t=t+1;
end
Umbral=minimo-1;
    

