function umbral = BIN_Concavidad(histograma,area)
%unsigned char BIN_Concavidad(unsigned long *histograma,unsigned long area)

	%for(i=255;!histograma[i];i--);
    %Localizar ultimo
    i=256;
    while (histograma(i) == 0)
        i = i-1;
    end
    
    ultimo=i;
    i=1;
    tramo=1;
    while(i < ultimo)
        nuevohisto(i)=0;
        if(histograma(i)>0)
            y0=histograma(i);
            x0=i;
            m_max=(histograma(i+1)-y0)/(i+1-x0);
            k=i+1;
            while(k<=ultimo)
                m=(histograma(k)-y0)/(k-x0);
                if(m>=m_max)
                    m_max=m;
                    j=k;
                end
                k=k+1;
            end %Fin de bucle for
            maximos(tramo)=i;
            k=i+1;
            while(k<j)
                nuevohisto(k)=y0+m_max*(k-x0)-histograma(k);
                if(nuevohisto(k)>nuevohisto(maximos(tramo)))
                    maximos(tramo)=k;
                end
                k = k+1;
            end %Fin de bucle for
            i=j;
            tramo = tramo+1;
            k = k+1;
        else
            i = i+1;
        end
    end
    
    i=ultimo;
    while(i<257)
		nuevohisto(i)=0;
        i = i+1;
    end
	maximo=0;
    
    %Comentarios
    
	m0=area;
	media=0;
    i=1;
	while(i<tramo)
        m00=0;
        j=1;
		while(j<maximos(i))
			m00= m00+histograma(j);
            j=j+1;
        end
        m01=m0-m00;
        media= media +(m00*m01);
        i = i+1;
    end
    media= media/i;
    maximo=1;
    i=1;
    while(i<tramo)
        m00=0;
        j=1;
		while(j<maximos(i))
			m00= m00+histograma(j);
            j=j+1;
        end
		m01=m0-m00;
		if((nuevohisto(maximos(i))>nuevohisto(maximos(maximo))) &&...
		   ((m00*m01)>(0.1*media)))
			maximo=i;
        end
        i=i+1;
    end
	umbral= maximos(maximo)-1;
    