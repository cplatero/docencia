function Umbral=BIN_Bimodal(histograma)
% unsigned char BIN_Bimodal(unsigned long *histograma);

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 21/05/03
%
%
i=1;
imax=0;
hmax=0;
max=0;
smax=0;
while(i<=256)
    if(histograma(i)>hmax)
        imax=i;
        hmax=histograma(i);
    end
    i=i+1;
end
i=1;
while ( i<imax+1)
    if(max<histograma(i))
        max=histograma(i);
    end
    if((max-histograma(i))>smax)
        smax=max-histograma(i);
        ibuscada=i;
    end
    i=i+1;
end
i=imax+1;
while(i<=256)
    if(max>histograma(i))
        max=histograma(i);
    end
    if(max-histograma(i)>smax)
        smax=max-histograma(i);
        ibuscada=i;
    end
    i=i+1;
end
Umbral=ibuscada-1;

        