function Umbral=BIN_EntropiaPun2(histograma,Area)
% unsigned char BIN_EntropiaPun2(unsigned long *histograma,unsigned long area);

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 20/05/03
%
%
HT=0;
i=1;
while(i<=256)
    prob(i)=histograma(i)/Area;
    if(prob(i)>0)
        HT= HT + (prob(i)*log(prob(i)));
    end
    i=i+1;
end
m=1;
while(m<=256)
    Hm=0;
    sumprobm=0;
    i=1;
    while(i<=m)
        sumprobm=sumprobm+prob(i);
        if(prob(i)>0)
            Hm=Hm+(prob(i)*log(prob(i)));
        end
        i=i+1;
    end
    if(sumprobm >= 0.5)
        break;
    end
    m=m+1;
end
alpha=Hm/HT;
sumprobi=0;
i=0;
if(alpha <= 0.5)
    i=1;
    while(i<=256)
        sumprobi=sumprobi+prob(i);
        if(sumprobi >= (1-alpha))
            break;
        end
        i=i+1;
    end
else 
    i=1;
    while(i<=256)
        sumprobi=sumprobi+prob(i);
        if(sumprobi>=alpha)
            break;
        end
        i=i+1;
    end
    m=m+1;
end
Umbral=i-1;

    
    
    