function Umbral=BIN_Monomodal(histograma,Area)
% unsigned char BIN_Bimodal(unsigned long *histograma,unsigned long area);

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 21/05/03
%
%
ibuscada=1;
while(ibuscada<=256)
    histointer(ibuscada)=0;
    ibuscada=ibuscada+1;
end
ibuscada=1;
i=1;
hmax=0;
imax=0;
sumder=0;
sumizq=0;
epsi=0;
while(i<=256)
    if(histograma(i)>hmax)
        imax=i;
        hmax=histograma(i);
    end
    i=i+1;
end
i=1;
while(i<imax+1)
    sumder=sumder+histograma(i);
    i=i+1;
end
i=1;
while(i<imax+1)
    sumizq=sumizq+histograma(i);
    sumder=sumder-histograma(i);
    if(sumder~=0)
        histointer(i)=sumizq/sumder;
    else
        histointer(i)=sumizq;
    end
    i=i+1;
end
sumizq=0;
sumder=0;
i=imax+1;
while(i<=256)
    sumder=sumder+histograma(i);
    i=i+1;
end
i=imax+1;
while(i<=256)
    sumizq=sumizq+histograma(i);
    sumder=sumder-histograma(i);
    if(sumder~=0)
        histointer(i)=sumder/sumizq;
    else
        histointer(i)=sumder;
    end
    i=i+1;
end
if(Area<40000)
    epsi=0.006;
else
    epsi=0.001;
end
ibuscada=1;
while(histointer(ibuscada)<epsi)
    ibuscada=ibuscada+1;
end
Umbral=ibuscada-1;


    