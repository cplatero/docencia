function Umbral=BIN_Otsu(histograma,Area)
%unsigned char BIN_Otsu(unsigned long *histograma,unsigned long area)

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 16/05/03
% Corregido
%

i=1;
mutotal=0;
while(i<=256)
    mutotal=mutotal+(i*histograma(i));
   
    i=i+1;
end 
mutotal=mutotal/Area;
mu=0;
w0=0;
m=0;

Umbral=0;
% Ir Inicializando a 0 los valores del array varinter
max=1;
while(max<=256)
    varinter(max)=0;
    max=max+1;
end
max=1;
i=1;
while(i<=256)
    mu=mu+((i*histograma(i))/Area);
    w0=w0+(histograma(i)/Area);
    if w0~=0 & w0~=1
        varinter(i)=(((mutotal*w0-mu)^2)/(w0*(1-w0)));
    else 
        varinter(i)=0;
      
    end   
    %maximo=186;
    auxiliar=varinter(i);
    auxiliar1=varinter(max); 
    if (auxiliar > auxiliar1)
        max=i;
    end
    i=i+1;
end

Umbral=max-1;
    

