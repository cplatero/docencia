function Umbral=BIN_EntropiaJB(histograma,Area)
% unsigned char BIN_EntropiaJB(unsigned long *histograma,unsigned long area);

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 21/05/03
%
%
minimo=1;
while(minimo<=256)
    Ssuma(minimo)=0;
    minimo=minimo+1;
end
minimo=1;

i=1;
while(i<=256)
    prob(i)=histograma(i)/Area;
    i=i+1;
end
primero=0;

t=1;
while(t<=256)
    sumprobhasta=0;
    i=1;
    while(i<=t)
        sumprobhasta=sumprobhasta+prob(i);
        i=i+1;
    end
    if(sumprobhasta>0)
        if((prob(t)>0) & (sumprobhasta ~= prob(t)))
            Shasta=log(sumprobhasta)-(1/sumprobhasta)*((prob(t)*log(prob(t)))+(sumprobhasta-prob(t))*log((sumprobhasta-prob(t))));
        else
            Shasta=0;
        end
    else
        Shasta=-1;
    end
    sumprobdesde=0;
    i=t;
    while(i<=256)
        sumprobdesde=sumprobdesde+prob(i);
        i=i+1;
    end
    if(sumprobdesde > 0)
        if((prob(t)>0) & (sumprobdesde ~= prob(t)))
            Sdesde=log(sumprobdesde)-(1/sumprobdesde)*((prob(t)*log(prob(t)))+(sumprobdesde-prob(t))*log((sumprobdesde-prob(t))));
        else
            Sdesde=0;
        end
    else
        Sdesde=-1;
    end
    Ssuma(t)=Shasta+Sdesde;
    if((Shasta>0) & (Sdesde>0) & (primero==0))
        minimo=t;
        primero=primero+1;
    end
    
    if((Shasta >0) & (Sdesde>0))
        if(Ssuma(t)<Ssuma(minimo))
            minimo=t;
        end
    end
    t=t+1;
end
Umbral=minimo-1;

    
        
    
    