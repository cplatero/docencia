function Umbral=BIN_EntropiaKSW(histograma,Area)
% unsigned char BIN_EntropiaKSW(unsigned long *histograma,unsigned long area);

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 20/05/03
%
%

maximo=1;
while(maximo<=256)
    H(maximo)=0;
    maximo=maximo+1;
end
i=1;
while(i<=256)
    prob(i)=histograma(i)/Area;
    i=i+1;
end
maximo=1;
t=1;

while(t<=256)
    sumprob=0;
    i=1;
    while(i<=t)
        sumprob=sumprob+prob(i);
        i=i+1;
    end
    Hb=0;
    i=1;
    while(i<=t)
        if(prob(i)>0)
            Hb=Hb-((prob(i)/(sumprob))*log(prob(i)/sumprob));
        else
            Hb=Hb-0;
        end
        i=i+1;
    end
    Hw=0;
    if(sumprob ~=1)
        i=t+1;
        while(i<=256)
            if(prob(i)>0)
                Hw=Hw-((prob(i)/(1-sumprob))*log(prob(i)/(1-sumprob)));
            else
                Hw=Hw-0;
            end
            i=i+1;
        end
    end
    H(t)=Hb+Hw;
    if(H(t)>H(maximo))
        maximo=t;
    end
    t=t+1;
end
Umbral=maximo-1;


    
    