function umbral=BIN_ConcavModificada(histograma,area)
%unsigned char BIN_VarianzaContinua(unsigned long *histograma,unsigned long area)

% Objetivo: Pasar los metodos de umbralizacion de C++ a Matlab con un error
% maximo de +/- 1 pixel 

% Autor: David Lopez Peinado GVA/ELAI/UPM
% Fecha: 19/05/03
%
%
   i=256;
    while (histograma(i) == 0)
        i = i-1;
    end
    
    ultimo=i;
    i=1;
    tramo=1;
    while(i < ultimo)
        nuevohisto(i)=0;
        if(histograma(i)>0)
            y0=histograma(i);
            x0=i;
            m_max=(histograma(i+1)-y0)/(i+1-x0);
            k=i+1;
            while(k<=ultimo)
                m=(histograma(k)-y0)/(k-x0);
                if(m>=m_max)
                    m_max=m;
                    j=k;
                end
                k=k+1;
            end %Fin de bucle for
            inicio(tramo)=i;
            maximos(tramo)=i;
            k=i+1;
            while(k<j)
                nuevohisto(k)=y0+m_max*(k-x0)-histograma(k);
                if(nuevohisto(k)>nuevohisto(maximos(tramo)))
                    maximos(tramo)=k;
                end
                k = k+1;
            end %Fin de bucle for
            i=j;
            tramo = tramo+1;
            k = k+1;
        else
            i = i+1;
        end
    end
    
    i=ultimo;
    while(i<257)
		nuevohisto(i)=0;
        inicio(tramo)=ultimo;
        i = i+1;
    end
	maximo=0;
    
    %Comentarios
    
	m0=area;
	media=0;
    i=1;
	while(i<tramo)
        m00=0;
        j=1;
		while(j<maximos(i))
			m00= m00+histograma(j);
            j=j+1;
        end
        m01=m0-m00;
        media= media +(m00*m01);
        i = i+1;
    end
    media= media/i;
    maximo=1;
    i=1;
    while(i<tramo)
        m00=0;
        j=1;
		while(j<maximos(i))
			m00= m00+histograma(j);
            j=j+1;
        end
		m01=m0-m00;
		if((nuevohisto(maximos(i))>nuevohisto(maximos(maximo))) &&...
		   ((m00*m01)>(0.1*media)))
			maximo=i;
        end
        i=i+1;
    end
	umbral= maximos(maximo);
    
    % Principal diferencia con respecto a BIN_Concavidad
    i=maximos(maximo);
    while (i<inicio(maximo+1))
        if (histograma(i)<histograma(umbral))
            umbral=i;
        end
        i=i+1;
    end
    i=maximos(maximo);
    while(i>inicio(maximo))
        if (histograma(i)<histograma(umbral))
            umbral=i;
        end
        i=i-1;
    end
    umbral = umbral -1;

