function ImgSal = ImagResMarcado(ImgEnt,ImgObj1)
%Objetivos
%	Marcar el perimetro en la imagen original de los objetos
%
%Synopsis
%	ImgSal = ImagResMarcado(ImgEnt,ImgObj)
%   ImgEnt: Imagen original RGB
%   ImgObj: Imagen logica de los objetos seleccionados
%Descripci�n
%	
%
%Autor: Carlos Platero ELAI-UPM
%Rev 0.0.0
%13/03/03

%Perimetro de los objetos y amplificador por una dilatacion
ImgPerim1 = imdilate(bwperim(ImgObj1),strel('square',2));

if (size(ImgEnt,3)==3)
    ImgRojo=ImgEnt(:,:,1);
    ImgVerde=ImgEnt(:,:,2);
    ImgAzul=ImgEnt(:,:,3);
    %Entorno Objeto 1 en rojo
    ImgRojo(ImgPerim1)=255;
    ImgVerde(ImgPerim1)=0;
    ImgAzul(ImgPerim1)=0;
    %Componer
    ImgSal(:,:,1)=ImgRojo;
    ImgSal(:,:,2)=ImgVerde;
    ImgSal(:,:,3)=ImgAzul;
else
    ImgSal=ImgEnt;
    ImgSal(ImgPerim1)=0;
end
 