imgEnt=imread('cables_gris.bmp');
imgBorde=edge(imgEnt,'canny',.4,2);
theta = 0:180;
[acum,rho] = radon(imgBorde,theta);
imagesc(theta,rho,acum), colorbar;
xlabel ('theta (grados)'), ylabel ('rho (pixeles desde el centro)')
title('Espacio de l�neas');
[x,y] = find(acum>100);
hold on; plot(theta(y),rho(x),'*r');hold off;
t = -theta(y')*pi/180;
pause;
lineas = [cos(t)' sin(t)' -rho(x)];
cy = size(imgEnt,1)/2-1;
cx = size(imgEnt,2)/2-1;

lineas(:,3) = lineas(:,3) - lineas(:,1)*cx - lineas(:,2)*cy;
imshow(imgEnt);
draw_lines(lineas);