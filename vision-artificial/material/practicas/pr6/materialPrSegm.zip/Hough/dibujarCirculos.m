function dibujarCirculos(radio,xcentro,ycentro)

x=xcentro-radio:radio/10:xcentro+radio;
y1 = ycentro +((radio*radio)-(x-xcentro).^2).^.5;
y2 = ycentro -((radio*radio)-(x-xcentro).^2).^.5;
plot(x,y1,'r');
plot(x,y2,'r');
