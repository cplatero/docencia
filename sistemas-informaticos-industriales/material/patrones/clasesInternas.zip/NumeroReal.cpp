#include <vector>
#include <iostream>
using namespace std;
class IEntero{
public:
	virtual int getEntero() = 0;
};

class NumeroReal{
	float valor;
//public:
	class NotificadorEntero;
	friend class NumeroReal::NotificadorEntero;
	class NotificadorEntero : public IEntero {
		NumeroReal *parent;
	public:
		NotificadorEntero(NumeroReal *p):parent(p){}
		int getEntero() {return (int) parent->valor;}
	} elNotificador;
public:
	NumeroReal(float v):valor(v),elNotificador(this){}
	operator IEntero *(){return &elNotificador;}
};


int main(){
	
	NumeroReal real(3.1416f);
	IEntero *pEntero = real; 
	cout << pEntero->getEntero();
	return 0;
}







