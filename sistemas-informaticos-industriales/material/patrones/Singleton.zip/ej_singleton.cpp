#include <iostream>
using namespace std;

class GlobalClass
{
    int m_value;
	GlobalClass(int v = 0): m_value (v){}
  public:
    int get_value(){
        return m_value;
    }
    void set_value(int v){
        m_value = v;
    }
    static GlobalClass *instance(){
		static GlobalClass s_instance;
        return &s_instance;
    }
};

void foo(void)
{
  GlobalClass::instance()->set_value(1);
  cout << "foo: global_ptr is " << GlobalClass::instance()->get_value() << '\n';
}

void bar(void)
{
  GlobalClass::instance()->set_value(2);
  cout << "bar: global_ptr is " << GlobalClass::instance()->get_value() << '\n';
}

int main()
{
  cout << "main: global_ptr is " << GlobalClass::instance()->get_value() << '\n';
  foo();
  bar();

  return 0;
}