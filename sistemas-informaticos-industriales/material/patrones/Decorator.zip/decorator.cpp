#include <string>
#include <iostream>
using namespace std;

class Coche
{
protected:
	string modelo;

public:
	Coche(){
      modelo = "Sin definir";
     }
	virtual string getDescripcion(){
		return modelo;
	}
	virtual double getPrecio() = 0;
 
    virtual ~Coche(){
		cout << "~Coche()\n";
    }
};
 
class OpcionesCoche : public Coche
{
public:
	virtual string getDescripcion() = 0;
	virtual ~OpcionesCoche(){
		cout<<"~OpcionesCoche()\n";
	}
};
 
 
class SeatLeon : public Coche
{       
public:
	SeatLeon(){
		modelo = "SeatLeon";
    }
	virtual double getPrecio(){
		return 12000;
    }
	~SeatLeon(){
		cout<<"~SeatLeon()\n";
    }
};
 
 
class Navegador: public OpcionesCoche
{
	Coche *base;
public:
	Navegador(Coche *b){
		base = b;
    }
	string getDescripcion(){
		return base->getDescripcion() + ", Navegador";
    }
	double getPrecio(){
		return 300 + base->getPrecio();
	}
    ~Navegador(){
		cout << "~Navegador()\n";
    }
};
 
class AireAcondicionado : public OpcionesCoche
{
	Coche *base;
public:
	AireAcondicionado(Coche *b){
		base = b;
    }
	string getDescripcion(){
		return base->getDescripcion() + ", Aire Acondicionado";
	}
	double getPrecio(){
		return 450 + base->getPrecio();
	}
	~AireAcondicionado(){
		cout << "~AireAcondicionado()\n";
    }
};
 
class TechoSolar : public OpcionesCoche
{
	Coche *base;
public:
	TechoSolar(Coche *b){
		base = b;
    }
	string getDescripcion(){
		return base->getDescripcion() + ", Techo Solar";
	}
	double getPrecio(){
		return 800 + base->getPrecio();
	}
	~TechoSolar(){
		cout << "~TechoSolar()\n";
    }
};
 
int main()
{
	Coche *modelo = new SeatLeon();
	cout << "Modelo base " << modelo->getDescripcion() << " precio " << modelo->getPrecio() << " euros\n";  
            
    modelo = new Navegador(modelo);
    cout << modelo->getDescripcion() << " cuesta " << modelo->getPrecio() << " euros\n";
    modelo = new AireAcondicionado(modelo);
    //modelo = new TechoSolar(modelo);
    cout << modelo->getDescripcion() << " cuesta " << modelo->getPrecio() << " euros\n";

    delete modelo;  

    return 0;
}