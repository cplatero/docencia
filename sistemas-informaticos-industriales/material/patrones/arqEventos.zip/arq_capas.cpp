#include <iostream>
#include <vector>
#include <algorithm>

// Interfaz para los Observadores
#include "Observer.h"
#include "Observable.h"



// Sujeto / Observable ( Sensor de Temperatura)
class SensorControl {
private:
    std::string current_status;
    class Notifier;
    friend class SensorControl::Notifier;
    class Notifier : public Observable{
        Argument arg;
        SensorControl* parent;
    public:
        Notifier(SensorControl* p) :parent(p) {
            arg.status = parent->current_status;
        }
        void notify() {
            setChanged();
            arg.status = parent->current_status;
            notifyObservers(&arg);
        }

    }notificador;
public:
    SensorControl() :current_status("init"), notificador(this) {}
    void addObserver(Observer& o) { notificador.addObserver(o); }
    void setStatus(const std::string& new_status) {
        std::cout << "[SENSOR] Nuevo estado: " << new_status << std::endl;
        current_status = new_status;
        notificador.notify(); // Notificar a todos los observadores
    }

    
};

// Observador 1: La Interfaz de Usuario (HMI)
class HMI{
    class ObserverSensor : public Observer {
    public:
        void update(Observable*, Argument* pArg) {
            std::cout << "[HMI] Actualizando display: " << pArg->status << std::endl;
        }
    }observadorSensor;

public:
    HMI() {}
    Observer& getObserver() {
        return observadorSensor;
    }
  
};

// Observador 2: El sistema de Registro (Logger)
class SystemLogger  {
    class ObserverSensor : public Observer {
    public:
        void update(Observable*, Argument* pArg) {
            std::cout << "[LOGGER] Registrando evento: " << pArg->status << std::endl;
        }
    }observadorSensor;
public:
    SystemLogger() {}
    Observer& getObserver() {
        return observadorSensor;
    }
    

};

// --- Uso del Patrón ---
int main() {
    SensorControl temp_sensor;

    HMI hmi_panel;
    SystemLogger data_logger;

    // Los observadores se suscriben al sensor
    temp_sensor.addObserver(hmi_panel.getObserver());
    temp_sensor.addObserver(data_logger.getObserver());

    // El sensor cambia de estado (genera un evento)
    temp_sensor.setStatus("ALERTA_CRITICA: Temperatura > 95C");

    std::cout << "---" << std::endl;

    temp_sensor.setStatus("Funcionamiento Normal");

    return 0;
}
