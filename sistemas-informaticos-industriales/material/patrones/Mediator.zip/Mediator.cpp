#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Mediator;
// Interfaz para los usuarios
class Colleague {
public:
    virtual void sendMessage( const string &message)  = 0;
    virtual void receiveMessage( const string &message) = 0;
    virtual void setMediator(Mediator *mediator) = 0;
};

// Mediator abstracto que define cómo los Colleagues se comunican entre sí
class Mediator {
public:
    virtual void sendMessage( const string &message,  Colleague *sender) = 0;
};

// ConcreteColleague: Usuario del chat
class User : public Colleague {
private:
    Mediator *mediator;
    string name;

public:
    User( const string &name) : name(name), mediator(nullptr) {}

    void setMediator(Mediator *mediator)  {
        this->mediator = mediator;
    }

    void sendMessage( const string &message)   {
        cout << name << " envia: " << message << endl;
        mediator->sendMessage(message, this);
    }

    void receiveMessage(const string &message)   {
        cout << name << " recibe: " << message << endl;
    }
};

// ConcreteMediator: Implementación del chat
class ChatRoom : public Mediator {
private:
    vector<Colleague *> users;

public:
    void addUser(Colleague *user) {
        users.push_back(user);
        user->setMediator(this);
    }

    void sendMessage( const string &message,  Colleague *sender)  {
        for (auto user : users) {
            if (user != sender) {
                user->receiveMessage(message);
            }
        }
    }
};

int main() {
    ChatRoom chat;

    User user1("Alicia");
    User user2("Rosa");
    User user3("Antonio");

    chat.addUser(&user1);
    chat.addUser(&user2);
    chat.addUser(&user3);

    user1.sendMessage("Hola a todos!");

    user2.sendMessage("Que tal, Alicia!");

    return 0;
}
