#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

class Component
{
protected:
	string name;
public:
	Component(string n) : name(n) {}
	virtual void add(Component*) {}
	virtual void show(unsigned) {}
	virtual ~Component() { cout << "Liberada memoria: " << name << endl; }  
};



class Composite : public Component
{
private:
	vector<Component*> list;
public:
	Composite(string n) : Component(n) {}
	void add(Component* component) {list.push_back(component);}
	void show(unsigned depth){
		cout << name << " nivel: " << depth << endl;
		for(unsigned i=0;i<list.size();i++)
			list[i]->show(depth+1);
	}
	virtual ~Composite() {
		for(unsigned i=0;i<list.size();i++)
			delete list[i];
	}

};


class Leaf : public Component
{
public:
	Leaf (string n) : Component(n) {}
	void add(Component*) {}
	void show(unsigned depth){
		cout << '-' << name << "    (" << depth << ')' << endl;
	}
};



int main()
{
	Composite* root = new Composite("raiz");
	root->add(new Leaf("hoja A"));
	root->add(new Leaf("hoja B"));
	
	Composite* branch = new Composite("rama");
	branch->add(new Leaf("hoja C"));
	branch->add(new Leaf("hoja D"));
	root->add(branch);


	root->add(new Leaf("hoja E"));
	root->add(new Leaf("hoja F"));

	root->show(0);

	delete root;
	return 0;
}