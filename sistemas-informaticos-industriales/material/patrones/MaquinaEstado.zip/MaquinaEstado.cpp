#include <iostream>
#include <typeinfo>
using namespace std;

class MaquinaEstado;

class Estado {  
protected:
  MaquinaEstado* maquina;
public:  
  void set_Maquina(MaquinaEstado* maquina_) {
        maquina = maquina_;
    }
  virtual void Do() = 0;
  virtual void SiguienteEtapa() = 0;
};

class MaquinaEstado {
    Estado* estado;
public:
 MaquinaEstado(Estado* estado_) : estado(estado_) {
   estado->set_Maquina(this);
   cout << "Maquina de Estado: estado inicial " 
    << typeid(*estado_).name() << ".\n";
  }
  ~MaquinaEstado() { delete estado;}
  void TransicionA(Estado* estado_) {
    cout << "Maquina de Estado: Transicion hacia " 
    << typeid(*estado_).name() << ".\n";
    if (estado != nullptr)
        delete estado;
    estado = estado_;
    estado->set_Maquina(this);
   }
   void SiguienteEtapa() { estado->SiguienteEtapa();}
   void Do() { estado->Do(); }
};


class PistonArriba : public Estado {
public:
    void Do() { cout << "Subir piston.\n"; }
    void SiguienteEtapa();

};

class PistonAbajo : public Estado {
public:
    void Do() { cout << "Bajar piston.\n"; }
    void SiguienteEtapa() { maquina->TransicionA(new PistonArriba); }
};

void PistonArriba::SiguienteEtapa() {
    maquina->TransicionA(new PistonAbajo);
}

/*void PistonAbajo::Do() {
    cout << "Subir piston.\n";
    maquina->TransicionA(new PistonArriba);
}*/


int main() {
MaquinaEstado* piston = 
new MaquinaEstado(new PistonArriba);
piston->Do();
piston->SiguienteEtapa();
piston->Do();
piston->SiguienteEtapa();

delete piston;
return 0;
}

