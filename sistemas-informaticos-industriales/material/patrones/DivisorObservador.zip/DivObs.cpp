// https://sourcemaking.com/design_patterns/observer/cpp/3

#include <iostream>
#include <vector>
using namespace std;

class Subject {
    vector < class Observer * > views; 
    int value;
  public:
    void attach(Observer *obs) {
        views.push_back(obs);
    }
    void setVal(int val) {
        value = val;
        notify();
    }
    int getVal() {
        return value;
    }
    void notify();
};

class Observer {
    Subject *model;
    int denom;
  public:
    Observer(Subject *mod, int div) {
        model = mod;
        denom = div;
        model->attach(this);
    }
    virtual void update() = 0;
  protected:
    Subject *getSubject() {
        return model;
    }
    int getDivisor() {
        return denom;
    }
};

void Subject::notify() {
  for (int i = 0; i < views.size(); i++)
    views[i]->update();
}

class DivObserver: public Observer {
  public:
    DivObserver(Subject *mod, int div): Observer(mod, div){}
    void update() {
        int v = getSubject()->getVal(), d = getDivisor();
        cout << v << " div " << d << " is " << v / d << '\n';
    }
};

class ModObserver: public Observer {
  public:
    ModObserver(Subject *mod, int div): Observer(mod, div){}
    void update() {
        int v = getSubject()->getVal(), d = getDivisor();
        cout << v << " mod " << d << " is " << v % d << '\n';
    }
};

class MulObserver: public Observer {
  public:
    MulObserver(Subject *mod, int mul): Observer(mod, mul){}
    void update() {
        int v = getSubject()->getVal(), d = getDivisor();
        cout << v << " mul " << d << " is " << v * d << '\n';
    }
};

int main() {
  Subject subj;
  DivObserver divObs1(&subj, 4); 
  DivObserver divObs2(&subj, 3); 
  ModObserver modObs3(&subj, 3);
  MulObserver mulObs4(&subj,2);
  subj.setVal(12);
}