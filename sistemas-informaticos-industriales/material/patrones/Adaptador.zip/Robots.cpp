#include <iostream>
#include <string>

class RobotWizo {
public:
    void encenderBluetooth()
    {
        std::cout<< "Bluetooth correctamente encendido\n";
    }
    void apagarBluetooth()
    {
	std::cout<< "Bluetooth apagado\n";
    }
    void mover(float x, float y)
    {
	std::cout<< "Moviendo motores Wizo...\n";
    }
};

class RobotDico {
public:
    bool checkNextPos(float x, float y) {
	std::cout<< "Checking position ...\n";
	return true; // podria devolver false / true
    }
    void go(float x, float y) {
	if (checkNextPos(x, y))   
	  std::cout<< "Going Dico to... " << x << " and " << y << "\n";
	else
	  std::cout<< "Impossible movement\n";
    }
    void connectWifi() {
        std::cout<< "Connected by Wifi\n";
    }
    void disconnectWifi() {
        std::cout<< "Disconnected Wifi\n";
    }
};

class IRobot
{
private:
    float x, y;
public:
    virtual void conectar() = 0;
    virtual void mover(float x, float y) = 0;
	virtual ~IRobot() {}
};

class ARobotWizo : public IRobot {
private:
    RobotWizo robot;
public:
    ARobotWizo() {}
    virtual ~ARobotWizo() {
	robot.apagarBluetooth();
    }
    void conectar() {
	robot.encenderBluetooth();
    }
    void mover(float x, float y) {
	robot.mover(x, y);
    }
};

class ARobotDico : public IRobot {
private:
    RobotDico robot;
public:
    ARobotDico() {}
    virtual ~ARobotDico() {
	robot.disconnectWifi();
    }
    void conectar() {
	robot.connectWifi();
    }
    void mover(float x, float y) {
        robot.go(x, y);
    }
};

int main(int argc, char* argv[])
{
    IRobot *aRobot = 0;
    char tipo;
    float x, y;
    std::cout << "Introduzca robot a controlar: {Z, D}: ";
    std::cin >> tipo;
    if (tipo == 'Z')
    {
        aRobot = new ARobotWizo();
    }
    else if (tipo == 'D')
    {
        aRobot = new ARobotDico();
    }
    if(aRobot)
    {
	aRobot->conectar();
    	std::cout << "Introduzca la posicion x: ";
    	std::cin >> x;
    	std::cout << "Introduzca la posicion y: ";
    	std::cin >> y;
	aRobot->mover(x, y);
	delete aRobot;
    }
    return 0;
};
