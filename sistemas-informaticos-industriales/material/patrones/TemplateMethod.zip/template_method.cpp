#include <iostream>

using namespace std;

// Clase base abstracta que define el Template Method para la preparación de una bebida
class Bebida {
    // Métodos concretos compartidos por las subclases
    void hervirAgua() {
        cout << "Hirviendo agua" << std::endl;
    }

    void vertirEnTaza() {
        cout << "Vertiendo en la taza" << std::endl;
    }

    // Métodos abstractos que deben ser implementados por las subclases
    virtual void elaborar() = 0;
    virtual void addCondimentos() = 0;

    // Método hook que las subclases pueden sobrescribir si es necesario
    virtual bool opciones() {
        return true;
    }

public:
    // Método Template Method que define el proceso de preparación de la bebida
    void prepareBebida() {
        hervirAgua();
        elaborar();
        vertirEnTaza();
        if (opciones()) {
            addCondimentos();
        }
    }

};

// Clase que hereda de Bebida y define los pasos específicos para hacer café
class Cafe : public Bebida {
//private:
    void elaborar()  {
        cout << "Colando cafe en el agua caliente" << endl;
    }

    void addCondimentos()  {
        cout << "Añadiendo azucar y leche al cafe" << 
            endl;
    }

    bool opciones()  {
        // El cliente puede querer personalizar su café, se sobrescribe el hook
        // Aquí podrías tener lógica adicional, como preguntar al usuario
        return false;
    }
};

// Clase que hereda de Bebida y define los pasos específicos para hacer té
class Te : public Bebida {
//private:
    void elaborar()  {
        cout << "Sumergiendo la bolsita de te en el agua caliente" << endl;
    }

    void addCondimentos() {
        cout << "Poniendo limon al te" << endl;
    }
};

int main() {
    // Preparar café
    cout << "Preparando cafe:" << endl;
    Cafe cafe;
    cafe.prepareBebida();

    cout << endl;

    // Preparar té
    cout << "Preparando te:" << endl;
    Te te;
    te.prepareBebida();

    return 0;
}
