#include <iostream>
using namespace std;

class CalculadorCosteCompras{
public:
	virtual float getCosteCompra() = 0;
};


class GestorCompras;
class Factoria{
	Factoria() {}
public:
	static Factoria * getInstancia(){
		static Factoria factoria;
		return &factoria;
	}	
	CalculadorCosteCompras * crearCalculador(unsigned,GestorCompras *);
};

class GestorCompras{
	unsigned numArticulos, tipoPrecio;
	float precioUnitario,iva;
	CalculadorCosteCompras *pCalculador;
public:
	GestorCompras(unsigned num, float precio, float i, unsigned tP):numArticulos(num),
		precioUnitario(precio),iva(i),tipoPrecio(tP){
			pCalculador=Factoria::getInstancia()->crearCalculador(tipoPrecio,this);
	}
	~GestorCompras() { if(pCalculador) delete pCalculador; }
	float getCosteCompra() { return pCalculador->getCosteCompra(); }
	unsigned getNumArticulos() { return numArticulos; }
	float getPrecioUnitario() { return precioUnitario; }
	float getIVA() { return iva; }
};


class PrecioOrdinario : public CalculadorCosteCompras {
	GestorCompras *pGestor;
	friend class Factoria;
	PrecioOrdinario(GestorCompras *pG):pGestor(pG) {}
public:
	float getCosteCompra(){
		return (pGestor->getNumArticulos()*pGestor->getPrecioUnitario())*(1+(pGestor->getIVA()/100));
	}
};

class DosXUno : public CalculadorCosteCompras {
	GestorCompras *pGestor;
	friend class Factoria;
	DosXUno(GestorCompras *pG):pGestor(pG) {}
public:
	float getCosteCompra(){
		return ((pGestor->getNumArticulos()/2+pGestor->getNumArticulos()%2)
			*pGestor->getPrecioUnitario())*(1+(pGestor->getIVA()/100));
	}
};

class DiaSinIVA : public CalculadorCosteCompras {
	GestorCompras *pGestor;
	friend class Factoria;
	DiaSinIVA(GestorCompras *pG):pGestor(pG) {}
public:
	float getCosteCompra(){
		return (pGestor->getNumArticulos()*pGestor->getPrecioUnitario());
	}
};




CalculadorCosteCompras * Factoria::crearCalculador(unsigned tipoPrecio,GestorCompras *pGestor){
		if(tipoPrecio==0) return new PrecioOrdinario(pGestor);
		else if(tipoPrecio==1) return new DosXUno(pGestor);
		else if(tipoPrecio==2) return new DiaSinIVA(pGestor);
		else return NULL;
}





int main()
{
	unsigned numArticulos, tipoPrecio;
	float precioUnitario,iva;
	cout << "Numero de articulos a comprar: ";
	cin >> numArticulos;
	cout << "Precio unitario del articulo: ";
	cin >> precioUnitario;
	cout << "IVA en tanto porciento: ";
	cin >> iva;
	cout << "Precio ordinario (0), Dos x uno (1), ";
	cout << "Dia sin IVA (2): ";
	cin >> tipoPrecio;
	GestorCompras elGestor(numArticulos, precioUnitario,iva, tipoPrecio);
	cout << "El coste de la compra es: " << elGestor.getCosteCompra() << endl;
	return 0;


}