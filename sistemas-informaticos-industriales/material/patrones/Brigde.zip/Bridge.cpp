#include <iostream>
using namespace std;


class DibujandoAPI {
  public:
   virtual void dibujaCirculo(double x, double y, double radius) = 0;
   //virtual ~DibujandoAPI() {}
};


class DibujandoAPI1 : public DibujandoAPI {
  public:
   void dibujaCirculo(double x, double y, double radio) {
      cout << "API1.circulo en " << x << ':' << y << ' ' << radio << endl;
   }
};

class DibujandoAPI2 : public DibujandoAPI {
  public:
   void dibujaCirculo(double x, double y, double radio) {
      cout << "API2.circulo en " << x << ':' << y << ' ' << radio << endl;
   }
};



class Forma {
  public:
   //virtual ~Forma() {}
   virtual void dibuja() = 0;
   virtual void escalado(double pct) = 0;
};


class Circulo : public Forma {
  public:
   Circulo(double x, double y,double radio, DibujandoAPI *dibujandoAPI) :
	   m_x(x), m_y(y), m_radio(radio), m_dibujandoAPI(dibujandoAPI)
   {}
   void dibuja() {
      m_dibujandoAPI->dibujaCirculo(m_x, m_y, m_radio);
   }
   void escalado(double pct) {
      m_radio *= pct;
   }
  private:
   double m_x, m_y, m_radio;
   DibujandoAPI *m_dibujandoAPI;
};

int main(void) {
   Circulo circulo1(1,2,3,new DibujandoAPI1());
   Circulo circulo2(5,7,11,new DibujandoAPI2());
   circulo1.escalado(2.5);
   circulo2.escalado(2.5);
   circulo1.dibuja();
   circulo2.dibuja();
   return 0;
}