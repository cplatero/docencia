#include <iostream>
#include <string>

#include <iostream>
#include <string>
using namespace std;

class Printer {
public:
    virtual void print(const string& text) = 0;
};


class OldPrinter {
public:
    void printText(const string& text) {
        cout << "OldPrinter: " << text << endl;
    }
};

// Adaptador que hace que OldPrinter sea compatible con la interfaz Printer
class PrinterAdapter : public Printer {
private:
    OldPrinter* oldPrinter; // Composición: incluye una instancia de OldPrinter
    friend class Factoria;
    PrinterAdapter(OldPrinter* printer) : oldPrinter(printer) {}

public:

    void print(const string& text) {
        // Llama al método del OldPrinter adaptado
        oldPrinter->printText(text);
    }
};


class Factoria {
    Factoria() {}
public:
    static Factoria& getinstance() {
        static Factoria instance;
        return instance;
    }
    Printer* newPrinter(OldPrinter* p) {
        return new PrinterAdapter(p);
    }
};
		
	

int main() {
    // Creamos una instancia de OldPrinter
    OldPrinter* oldPrinter = new OldPrinter();

    // Creamos un adaptador que lo haga compatible con la interfaz Printer
    Printer* printer = Factoria::getinstance().newPrinter(oldPrinter);

    // Usamos el adaptador para imprimir texto
    printer->print("Hello, world!");

    // Liberamos memoria
    delete printer;
    delete oldPrinter;

    return 0;
}
