#include<string>
#include<vector>
#include<iostream>
 using namespace std;
 
 
class Handler {
 public:
  virtual Handler *SetNext(Handler *handler) = 0;
  virtual string Handle(string request) = 0;
};

class AbstractHandler : public Handler {
 private:
  Handler *next_handler_;

 public:
  AbstractHandler() : next_handler_(nullptr) {}

  Handler *SetNext(Handler *handler) override {
    this->next_handler_ = handler;
    return handler;
  }
  string Handle(string request) override {
    if (this->next_handler_) {
      return this->next_handler_->Handle(request);
    }

    return {};
  }
};


class CentralitaHandler : public AbstractHandler {
 public:
  string Handle(string request) override {
    if (request == "Atencion") {
      return "Centralida: se encarga de la " + request + ".\n";
    } else {
      return AbstractHandler::Handle(request);
    }
  }
};

class TecnicoHandler : public AbstractHandler {
 public:
  string Handle(string request) override {
    if (request == "Desarrollo") {
      return "Tecnico: se encarga del " + request + ".\n";
    } else {
      return AbstractHandler::Handle(request);
    }
  }
};

class GerenteHandler : public AbstractHandler {
 public:
  string Handle(string request) override {
    if (request == "Responsabilidad") {
      return "Gerente: se encarga de la " + request + ".\n";
    } else {
      return AbstractHandler::Handle(request);
    }
  }
};


void ClientCode(Handler &handler) {
  vector<string> peticion = {"Desarrollo", "Atencion", "Queja"};
  for (const string &f : peticion) {
   cout << "Cliente: quiere que le atienda " << f << "?\n";
    const string result = handler.Handle(f);
    if (!result.empty()) {
      cout << "  " << result;
    } else {
      cout << "  " << f << " no fue atendida.\n";
    }
  }
}


int main() {
  CentralitaHandler *centralida = new CentralitaHandler;
  TecnicoHandler *tecnico = new TecnicoHandler;
  GerenteHandler *gerente = new GerenteHandler;
  centralida->SetNext(tecnico)->SetNext(gerente);

  /**
   * The client should be able to send a request to any handler, not just the
   * first one in the chain.
   */
  cout << "Cadena de responsabilidades: centralida > Tecnico > Gerente\n\n";
  ClientCode(*centralida);
  cout << "\n";
  cout << "Subcadena de responsabilidades: Tecnico > Gerente\n\n";
  ClientCode(*tecnico);

  delete centralida;
  delete tecnico;
  delete gerente;

  return 0;
}