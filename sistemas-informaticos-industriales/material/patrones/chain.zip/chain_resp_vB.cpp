#include<string>
#include<vector>
#include<iostream>
 using namespace std;
 
 
class Cargo {
 public:
  virtual Cargo *setNext(Cargo *Cargo) = 0;
  virtual string asunto(string pedido) = 0;
};

class DelegarResponsabilidad : public Cargo {
 private:
  Cargo *next_Cargo_;

 public:
  DelegarResponsabilidad() : next_Cargo_(nullptr) {}

  virtual Cargo *setNext(Cargo *Cargo)  {
    this->next_Cargo_ = Cargo;
    return Cargo;
  }
  virtual string asunto(string pedido)  {
    if (this->next_Cargo_) {
      return this->next_Cargo_->asunto(pedido);
    }

    return {};
  }
};


class Centralida : public DelegarResponsabilidad {
 public:
  virtual string asunto(string pedido)  {
    if (pedido == "Atencion") {
      return "Centralida: se encarga de la " + pedido + ".\n";
    } else {
      return DelegarResponsabilidad::asunto(pedido);
    }
  }
};

class Tecnico : public DelegarResponsabilidad {
 public:
  virtual string asunto(string pedido)  {
    if (pedido == "Desarrollo") {
      return "Tecnico: se encarga del " + pedido + ".\n";
    } else {
      return DelegarResponsabilidad::asunto(pedido);
    }
  }
};

class Gerente : public DelegarResponsabilidad {
 public:
  virtual string asunto(string pedido)  {
    if (pedido == "Queja") {
      return "Gerente: se encarga de la " + pedido + ".\n";
    } else {
      return DelegarResponsabilidad::asunto(pedido);
    }
  }
};


void ClientCode(Cargo &cargo) {
  vector<string> peticion = {"Desarrollo", "Atencion", "Queja", "Saludo"};
  for (const string &f : peticion) {
   cout << "Cliente: quiere que le atienda " << f << "\n";
    const string result = cargo.asunto(f);
    if (!result.empty()) {
      cout << "  " << result;
    } else {
      cout << "  " << f << " no fue atendida.\n";
    }
  }
}


int main() {
  Centralida *centralida = new Centralida;
  Tecnico *tecnico = new Tecnico;
  Gerente *gerente = new Gerente;
  centralida->setNext(tecnico)->setNext(gerente);

  /**
   * The client should be able to send a pedido to any handler, not just the
   * first one in the chain.
   */
  cout << "Cadena de responsabilidades: centralida > Tecnico > Gerente\n\n";
  ClientCode(*centralida);
  cout << "\n";
  cout << "Subcadena de responsabilidades: Tecnico > Gerente\n\n";
  ClientCode(*tecnico);

  delete centralida;
  delete tecnico;
  delete gerente;

  return 0;
}