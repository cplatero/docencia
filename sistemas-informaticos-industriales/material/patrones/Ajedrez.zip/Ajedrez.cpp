#include <vector>
#include <iostream>
using namespace std;

typedef enum{REY,PEON} TipoPieza;
typedef enum{MADERA} TipoTablero;
typedef enum{BLANCO,NEGRO} Color;

class Pieza{
public:
	virtual char * getTipoPieza()=0;
	virtual char * getColor()=0;
};


class Rey : public Pieza{
	Color color;
	friend class Factoria;
	Rey(Color c):color(c){}
	public:	
		char * getTipoPieza() {return "Rey";}
		char * getColor() { 
			if(color==BLANCO) return "Blanco";
			else return "Negro";
		}
};

class Peon : public Pieza{
	Color color;
	friend class Factoria;
	Peon(Color c):color(c){}
	public:
		
		char * getTipoPieza() {return "Peon";}
		char * getColor() { 
			if(color==BLANCO) return "Blanco";
			else return "Negro";
		}
};


class Tablero{
public:
	virtual void setPieza(Pieza *,char,int)=0;
	virtual char * getPosPieza(Pieza *)=0;
};

class PosPieza {
	Pieza *pieza;
	char colum;
	int fila;
	char res[3];
public:
	PosPieza(Pieza *p,int f,char c):pieza(p),fila(f),colum(c){}
	Pieza * getPieza() {return pieza;}
	char *getPos() {
		res[0]=colum;
		res[1]=(char)(fila+48);
		res[2]='\0';
		return res;
	}



};

class TableroMadera : public Tablero{
//	vector<Pieza *>vectorPieza;
	vector<PosPieza *> vectorPiezaPos;
	friend class Factoria;
	TableroMadera(){}
	~TableroMadera(){
		for(int i=0; vectorPiezaPos.size(); i++){
//			if(vectorPieza[i]) delete vectorPieza[i];
			if(vectorPiezaPos[i]->getPieza()) delete vectorPiezaPos[i]->getPieza();
		}
	}
	public:
		void setPieza(Pieza *p,char c,int f){
//			vectorPieza.push_back(p);
			vectorPiezaPos.push_back(new PosPieza(p,f,c));
		}
		char * getPosPieza(Pieza *p){
			int i=0;
			while(p != vectorPiezaPos[i]->getPieza()) i++;
			return vectorPiezaPos[i]->getPos();
		}


};
class Factoria
{
	Factoria(){}
public:
    static Factoria& getInstancia()
        {
            static Factoria unicaInstancia; 
            return unicaInstancia;
		}

          
    Pieza* crearPieza (TipoPieza tipo, Color c)
	{
        if(tipo == REY) return new Rey(c);
        else if(tipo == PEON ) return new Peon(c);
        else return NULL;
	}

   Tablero* crearTablero (TipoTablero tipo)
	{
        if(tipo == MADERA) return new TableroMadera;
        else return NULL;
	}
};


int main()
{
	Factoria &factoria= Factoria::getInstancia();
	Pieza *p1 = factoria.crearPieza(REY,BLANCO);
	Pieza *p2 = factoria.crearPieza(PEON,NEGRO);
	Tablero *tablero = factoria.crearTablero(MADERA);
	tablero->setPieza(p1,'e',8);
	tablero->setPieza(p2,'a',2);
	cout << "Pieza: " << p1->getTipoPieza() << " " << p1->getColor() << " " 
		 << tablero->getPosPieza(p1) << endl;
	cout << "Pieza: " << p2->getTipoPieza() << " " << p2->getColor() << " " 
		 << tablero->getPosPieza(p2) << endl;
	delete tablero;

}