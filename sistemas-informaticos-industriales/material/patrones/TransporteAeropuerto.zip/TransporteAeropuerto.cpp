#include <vector>
#include <iostream>
using namespace std;

typedef enum{BUS,TREN,TAXI} TipoTransporte;

class TransporteAeropuerto;
class Transporte{
protected:
	float tiempo;
	float precio;
public:
	virtual float getPrecio()=0;
	virtual float getTiempo()=0;
	static Transporte * crearTransporte(TipoTransporte,
		float,float,TransporteAeropuerto *);
};

class TransporteAeropuerto {
	Transporte *pTransporte;
	vector<float> precios;
	vector<float> tiempos;
	unsigned numPajeros;
public:
	float getPrecios() {return pTransporte->getPrecio();}
	float getTiempos() {return pTransporte->getTiempo();}
	unsigned getNumPasajeros() {return numPajeros;}
	TransporteAeropuerto( float *pPrecios, float *pTiempos,unsigned numTransportes) {
		for (unsigned i=0;i<numTransportes;i++) {
			tiempos.push_back(pTiempos[i]);
			precios.push_back(pPrecios[i]);
		}
	}
	void setPasaje(unsigned n, TipoTransporte elTipo){
		numPajeros=n;
		float precio,tiempo;
		if(elTipo == BUS){
			precio=precios[0];
			tiempo=tiempos[0];
		}
		else if(elTipo == TREN){
			precio=precios[1];
			tiempo=tiempos[1];
		}
		else {
			precio=precios[2];
			tiempo=tiempos[2];
		}
		pTransporte = Transporte::crearTransporte(elTipo,precio,tiempo,this);
	}
};


class BusAeropuerto : public Transporte{
	friend class Transporte;
	TransporteAeropuerto *pContexto;
	BusAeropuerto(float p, float t, TransporteAeropuerto *pC):pContexto(pC){
		precio=p;
		tiempo=t;
	}
	public:	
		float getPrecio() {return precio*pContexto->getNumPasajeros();}
		float getTiempo() {return tiempo;}

};

class TrenAeropuerto : public Transporte{
	friend class Transporte;
	TransporteAeropuerto *pContexto;
	TrenAeropuerto(float p, float t, TransporteAeropuerto *pC):	pContexto(pC){
		precio=p;
		tiempo=t;
	}
	public:	
		float getPrecio() {return precio*pContexto->getNumPasajeros();}
		float getTiempo() {return tiempo;}

};

class TaxiAeropuerto : public Transporte{
	friend class Transporte;
	TransporteAeropuerto *pContexto;
	TaxiAeropuerto(float p, float t, TransporteAeropuerto *pC):pContexto(pC){
		precio=p;
		tiempo=t;
	}
	public:	
		float getPrecio() {return precio;}
		float getTiempo() {return tiempo;}

};


Transporte * Transporte::crearTransporte(TipoTransporte elTipo, float precio,
								float tiempo,TransporteAeropuerto *pContexto){
	if(elTipo==BUS) return new BusAeropuerto(precio,tiempo,pContexto);
	else if (elTipo==TREN) return new TrenAeropuerto(precio,tiempo,pContexto);
	else return new TaxiAeropuerto(precio,tiempo,pContexto);
}

int main()
{
	//Precios del bus, tren y taxi desde el centro al aeropuerto
	float precios[]={ 3.0f, 2.5f, 40.0f};
	//Precios del bus, tren y taxi desde el centro al aeropuerto
	float tiempos[]={40.0f, 30.0f, 20.0f};
	unsigned numTransportes = 3;
	TransporteAeropuerto madridCentroAeropuerto(precios,tiempos,numTransportes);
	madridCentroAeropuerto.setPasaje(3,BUS);
	cout << "BUS: coste pasaje: " << madridCentroAeropuerto.getPrecios() << " euros";
	cout << "; Tiempo estimado: " << madridCentroAeropuerto.getTiempos() << " minutos\n";
	madridCentroAeropuerto.setPasaje(2,TAXI);
	cout << "Taxi: coste pasaje: " << madridCentroAeropuerto.getPrecios() << " euros";
	cout << "; Tiempo estimado: " << madridCentroAeropuerto.getTiempos() << " minutos\n";

	return 0;
}